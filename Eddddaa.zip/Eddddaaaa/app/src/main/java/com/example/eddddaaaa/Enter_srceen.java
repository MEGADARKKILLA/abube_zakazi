package com.example.eddddaaaa;

import android.content.Intent;
import android.os.Bundle;
import android.os.FileObserver;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import javax.xml.validation.Validator;

public class Enter_srceen extends AppCompatActivity {

    private EditText txtEmail;
    private EditText txtpass;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.enter_screen);
        txtEmail =(EditText) (findViewById(R.id.txtEmail));
        txtpass = (EditText) (findViewById(R.id.txtpass));
    }

    public void Reg2(View view){
        Intent intent1 = new Intent(this, Reg_screen.class);
        startActivity(intent1);}
    public void Check_Log(View view) {
  /*      boolean valid=true;
        if (txtEmail.length() < 10 && txtEmail.length()>=11){
            valid=false;
        Toast.makeText(this,"Enter valid phone",Toast.LENGTH_SHORT).show();

    }
        if (txtpass.length() < 6){
            valid=false;
            Toast.makeText(this,"enter pass min 6",Toast.LENGTH_SHORT).show();
        }
        if (txtpass.length() < 0){
            valid=false;
            Toast.makeText(this,"Enter the pass",Toast.LENGTH_SHORT).show();
        }
    if(valid==true)*/
    {
            Intent intent = new Intent(this, TestClass.class);
            startActivity(intent);
    }
    }
}




