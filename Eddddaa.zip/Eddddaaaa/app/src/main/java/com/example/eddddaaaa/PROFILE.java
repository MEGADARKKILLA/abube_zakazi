package com.example.eddddaaaa;

import androidx.appcompat.app.AppCompatActivity;

public class PROFILE extends AppCompatActivity
{
}
