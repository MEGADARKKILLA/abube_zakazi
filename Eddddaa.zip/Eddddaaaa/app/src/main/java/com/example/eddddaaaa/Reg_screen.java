package com.example.eddddaaaa;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Reg_screen extends AppCompatActivity {
    private EditText txtname;
    private EditText txt_Pass;
    private EditText txt_phone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.reg_screen);
        txtname =(EditText) (findViewById(R.id.txtName));
        txt_Pass = (EditText) (findViewById(R.id.txt_pass));
        txt_phone = (EditText) (findViewById(R.id.txtPhone));
    }
    public void Ceking(View view){
    boolean valid=true;
        if (txtname.length() < 0){
        valid=false;
        Toast.makeText(this,"Name must be",Toast.LENGTH_SHORT).show();

    }
        if (txt_Pass.length() < 6){
        valid=false;
        Toast.makeText(this,"enter pass min 6",Toast.LENGTH_SHORT).show();
    }
        if (txt_Pass.length() < 0){
        valid=false;
        Toast.makeText(this,"Enter the pass",Toast.LENGTH_SHORT).show();
    }
        if (txt_phone.length() < 10 && txt_phone.length()>=11){
            valid=false;
            Toast.makeText(this,"Enter the pass",Toast.LENGTH_SHORT).show();
        }

    if(valid==true)
    {
        Intent intent1 = new Intent(this, TestClass.class);
        startActivity(intent1);}
    }
    public void Log2(View view){
        Intent intent2 = new Intent(this, Enter_srceen.class);
        startActivity(intent2);
    }
}
