package com.example.eddddaaaa;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.HttpsURLConnection;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Test1Fragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Test1Fragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private List<Tovar>items= new ArrayList<>();
    private TovarAdapter tovarAdapter;
    private ListView listview;
    URL url;
    public Test1Fragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment Test1Fragment.
     */
    // TODO: Rename and change types and number of parameters
    public static Test1Fragment newInstance(String param1, String param2) {
        Test1Fragment fragment = new Test1Fragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        ViewGroup root = (ViewGroup) inflater.inflate(R.layout.fragment_test1, null);
        listview = (ListView) root.findViewById(R.id.listView);
        tovarAdapter= new TovarAdapter(container.getContext(),items);
        listview.setAdapter(tovarAdapter);
        try {
            url= new URL("http://localhost:1142/api/%D0%A2%D0%BE%D0%B2%D0%B0%D1%80%D1%8B");
        } catch (MalformedURLException e) {
            throw new RuntimeException(e);
        }
        synktask synk= new synktask();
        synk.execute(url);
        return inflater.inflate(R.layout.fragment_test1, container, false);
    }
    private class synktask extends AsyncTask<URL,Void,JSONObject> {

        @Override
        protected JSONObject doInBackground(URL...params) {
            HttpURLConnection connection =null;
            try
            {
                connection = (HttpURLConnection) params[0].openConnection();
                int responce = connection.getResponseCode();
                if(responce ==HttpsURLConnection.HTTP_OK){
                    StringBuilder builder=new StringBuilder();
                    try(BufferedReader reader=new BufferedReader(
                            new InputStreamReader(connection.getInputStream())
                    )){
                        String line;
                        while ((line=reader.readLine())!=null){
                            builder.append(line);
                        }
                    }
                    catch (IOException e){
                        e.printStackTrace();
                    }
                    return  new JSONObject(builder.toString());
                }
                else {
                }
            }
            catch (Exception e){
                e.printStackTrace();
                Log.e("!",e.getMessage());
            }
            finally {
                connection.disconnect();
            }
            return  null;
        }
        @Override
        protected void onPostExecute(JSONObject list){
            convetToArray(list);
            tovarAdapter.notifyDataSetChanged();
            listview.smoothScrollToPosition(0);
        }
        private void convetToArray(JSONObject forecast){
            items.clear();
            try{
                JSONArray list = forecast.getJSONArray("list");
                for(int i=0;i<list.length();i++){
                    JSONObject tovar=list.getJSONObject(i);
                    JSONObject Tovar=tovar.getJSONObject("Товар");
                    items.add(new Tovar(
                            Tovar.getInt("Цена"),
                            Tovar.getInt("Колличество"),
                            Tovar.getString("Наименование"),
                            Tovar.getString("Описание")
                    ));
                }
            }
            catch (JSONException e){
                e.printStackTrace();
            }
        }

    }
}