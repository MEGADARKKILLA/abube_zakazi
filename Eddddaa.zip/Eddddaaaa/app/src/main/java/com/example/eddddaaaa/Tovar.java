package com.example.eddddaaaa;

public class Tovar {

    public  final int price;
    public  final int quantity;
    public  final String desc;
    public  final String name;


    public Tovar( int price, int quantity, String desc, String name) {

        this.price = price;
        this.quantity = quantity;
        this.desc = desc;
        this.name = name;

    }
}
