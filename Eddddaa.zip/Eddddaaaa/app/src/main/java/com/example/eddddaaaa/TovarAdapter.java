package com.example.eddddaaaa;

import android.content.Context;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class TovarAdapter extends ArrayAdapter<Tovar> {
    public TovarAdapter(Context context, List<Tovar> forecast){
        super(context,-1,forecast);
    }
    public static class ViewHolder{
        TextView id_textview;
        TextView price_textview;
        TextView quantity_textview;
        TextView desc_textview;
        TextView name_textview;
        TextView cat_id_textview;
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        Tovar tovar1=getItem(position);
        ViewHolder viewHolder;
        if(convertView==null){
            viewHolder = new ViewHolder();
            LayoutInflater inflater= LayoutInflater.from(getContext());
            convertView = inflater.inflate(R.layout.simple_list,parent,false);
            viewHolder.id_textview =convertView.findViewById(R.id.text1);
            viewHolder.price_textview=convertView.findViewById(R.id.text2);
            viewHolder.quantity_textview=convertView.findViewById(R.id.text3);
            viewHolder.desc_textview=convertView.findViewById(R.id.text4);
            viewHolder.name_textview=convertView.findViewById(R.id.text5);
            viewHolder.cat_id_textview=convertView.findViewById(R.id.text6);
            convertView.setTag(viewHolder);
        }
        else {
            viewHolder = (ViewHolder)convertView.getTag();
        }
        Context context=getContext();
        viewHolder.price_textview.setText(tovar1.price);
        viewHolder.quantity_textview.setText(tovar1.quantity);
        viewHolder.desc_textview.setText(tovar1.desc);
        viewHolder.name_textview.setText(tovar1.name);
        return convertView;
    }
}
