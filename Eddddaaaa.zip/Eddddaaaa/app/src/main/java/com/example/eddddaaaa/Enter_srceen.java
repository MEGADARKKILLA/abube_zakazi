package com.example.eddddaaaa;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class Enter_srceen extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.enter_screen);
    }
    public void Reg2(View view){
        Intent intent1 = new Intent(this, Reg_screen.class);
        startActivity(intent1);}
    public void Check_Log(View view){
        Intent intent = new Intent(this, Main_menu.class);
        startActivity(intent);
    }

}
