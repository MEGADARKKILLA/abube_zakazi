package com.example.eddddaaaa;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void Reg(View view){
 Intent intent1 = new Intent(this, Reg_screen.class);
 startActivity(intent1);
    }
    public void Log(View view){
        Intent intent2 = new Intent(this, Enter_srceen.class);
        startActivity(intent2);
    }
}