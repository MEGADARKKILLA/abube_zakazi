package com.example.eddddaaaa;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.Menu;
import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;

public class Main_menu extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_menu);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.nenu, menu);
        return true;
    }
@Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id) {
            case R.id.nav_gallery:
                Intent intent = new Intent(this, Main_menu.class);
                return true;
            case R.id.nav_slideshow:
                Intent intent1 = new Intent(this, BASKET.class);
                return true;
            case R.id.nav_home:
                Intent intent2 = new Intent(this, PROFILE.class);
                return true;
        }
        return super.onOptionsItemSelected(item);
    }


}
