package com.example.eddddaaaa;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class Reg_screen extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.reg_screen);
    }
    public void Log2(View view){
        Intent intent1 = new Intent(this, Enter_srceen.class);
        startActivity(intent1);}

}
